# Preprocessed data
These .pickle files are needed for the app to run.
To preprocess, you need a sskj.html file (check /data/sskj). Run the following script:
```bash
$ cd script/valency/seqparser
$ python3 seqparser.py
```

## Files:

* `se_list.pickle` - List of verb lemmas that are ALWAYS found with "se" ("be"). Example: "gibati se".
* `sskj_senses.pickle` - Web app has a functionality "po meri" where you can add senses to sentences. 
Sskj senses are stored in `sskj_senses.pickle`. 
If mongo collection `db.v2_senses` contains no senses with author "SSKJ", they are loaded when app starts (`authostart.sh˙). 

